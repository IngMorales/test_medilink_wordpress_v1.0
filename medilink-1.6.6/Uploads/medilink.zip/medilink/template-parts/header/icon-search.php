<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Medilink;
?>
<div class="search-box-area">
	<div class="search-box">		
		<a href="#header-search" class="search-button"><i class="flaticon-search"></i></a>		
	</div>
</div>