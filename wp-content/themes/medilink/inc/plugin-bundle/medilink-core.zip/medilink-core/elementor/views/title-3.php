<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Medilink_Core;

?>

<div class="rt-el-title section-heading heading-dark heading-layout5 <?php echo esc_html( $data['style'] );?>">
	<h2 class="rtin-title"><?php echo wp_kses_post( $data['title'] );?></h2>
</div>

